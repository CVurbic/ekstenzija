// popup.js

document.addEventListener('DOMContentLoaded', function () {
  var refreshButton = document.getElementById('refreshButton');




  refreshButton.addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.reload(tabs[0].id);
    });
  });





  // Dohvaćanje tema iz lokalne pohrane
  chrome.storage.local.get('themes', function (data) {
    console.log(data)
    const themes = data.themes;
    if (themes && themes.length > 0) {
      // Generiranje gumba za svaku temu
      const themeButtonsDiv = document.querySelector('.themeButtons');
      themes.forEach(theme => {
        const button = document.createElement('button');
        button.textContent = theme.theme; // Pretpostavljajući da svaka tema ima svoje ime
        button.addEventListener('click', function () {
          // Slanje odabrane teme na content.js
          console.log('Button clicked');
          chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, { odabranaTema: theme.theme });
          });
        });
        themeButtonsDiv.appendChild(button);
      });
    } else {
      console.log('Nema dostupnih tema.');
    }
  });
});
