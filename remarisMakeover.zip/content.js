const orderIdColorMap = {};
let currentIndex = 0;
let theme = undefined;
let boje = undefined;
let sveBoje = [];

function hexToRgba(hex) {
  hex = hex.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, (m, r, g, b) => {
    return r + r + g + g + b + b;
  });

  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) {
    throw new Error("Invalid HEX color format");
  }

  const r = parseInt(result[1], 16);
  const g = parseInt(result[2], 16);
  const b = parseInt(result[3], 16);

  return `rgba(${r}, ${g}, ${b}, ${0.5})`;
}

function chooseNextColor() {
  const colorCount = boje.length;
  if (currentIndex >= colorCount) {
    currentIndex = 0;
  }
  const nextColor = boje[currentIndex];
  currentIndex++;
  return nextColor;
}

const allTicketItems = {};

function addItemToAllItems(itemName, itemId) {
  allTicketItems[itemId] = { itemName, itemId };
}

function processTicket(tbody) {
  const ticketItems = tbody.querySelectorAll(".ticket-item");

  ticketItems.forEach(item => {
    const itemName = item.querySelector("dt").innerText.trim();
    const itemId = parseInt(item.getAttribute("product-id"));
    addItemToAllItems(itemName, itemId);
  });

  const sortedItems = Object.values(allTicketItems).sort((a, b) => a.itemId - b.itemId);
  localStorage.setItem('sortedItems', JSON.stringify(sortedItems));
}

const keywords = ["TORTILJA", "LEPINJA", "POSUDA"];
const borderColors = ["green", "yellow", "blue"];

let colorIndex = 0;

function editGlovoTicket(tbody) {
  if (colorIndex >= borderColors.length) colorIndex = 0;

  const glovoTicket = tbody.getAttribute("table-code");
  if (glovoTicket === "GLOVO") {
    const ticketItems = tbody.querySelectorAll(".ticket-item");

    const lepinjaIndexes = [];

    ticketItems.forEach((item, index) => {
      const itemName = item.querySelector("dt").innerText.trim();
      if (keywords.some(keyword => itemName.includes(keyword))) {
        lepinjaIndexes.push(index);
      }
    });

    for (let i = 0; i < lepinjaIndexes.length - 1; i++) {
      const startIndex = lepinjaIndexes[i];
      const endIndex = lepinjaIndexes[i + 1];
      const itemsToSort = Array.from(ticketItems).slice(startIndex + 1, endIndex);

      const referenceNode = ticketItems[startIndex + 1];
      itemsToSort.forEach((item) => {
        tbody.insertBefore(item, referenceNode.nextSibling);
      });

      const borderColor = borderColors[colorIndex];
      const firstChildOfStartIndex = ticketItems[startIndex].querySelector("dt").parentNode;
      firstChildOfStartIndex.style.borderRight = `10px solid ${borderColor}`;
      firstChildOfStartIndex.style.borderTop = `1px solid ${borderColor}`;

      itemsToSort.forEach(item => {
        item.querySelectorAll("td")[1].style.borderRight = `10px solid ${borderColor}`;
      });

      colorIndex = (colorIndex + 1) % borderColors.length;
    }

    const lastLepinjaIndex = lepinjaIndexes[lepinjaIndexes.length - 1];
    const itemsToSortAfterLastLepinja = Array.from(ticketItems).slice(lastLepinjaIndex + 1);
    const referenceNodeAfterLastLepinja = ticketItems[lastLepinjaIndex];

    let i = 0;
    lepinjaIndexes.forEach(() => {
      if (i > borderColors.length) i = 0;
      itemsToSortAfterLastLepinja.forEach(item => {
        const borderColor = borderColors[i];
        const border = referenceNodeAfterLastLepinja.querySelector("dt").parentNode;
        border.style.borderRight = `10px solid ${borderColor}`;
        border.style.borderTop = `1px solid ${borderColor}`;
        item.querySelectorAll("td")[1].style.borderRight = `10px solid ${borderColor}`;
      });
      i++;
    });
    colorIndex++;
  }
}

function changeColor(tbodyElements) {
  tbodyElements.forEach((tbody) => {
    if (tbody.classList.contains("zero-progress-ticket")) {
      const ticketId = tbody.getAttribute("ticketid");
      let color;
      if (orderIdColorMap[ticketId]) {
        color = orderIdColorMap[ticketId];
      } else {
        color = chooseNextColor();
        orderIdColorMap[ticketId] = color;
      }
      const innerDiv = tbody.querySelector(".ticket_first_half_completed");
      if (innerDiv) {
        innerDiv.style.backgroundColor = color;
      }
      applyStylingToNewElement(tbody, color);
    }
  });

  function handleTbodyClick(event) {
    const currentlySelected = document.querySelector(".selected-ticket");
    if (currentlySelected !== null) {
      currentlySelected.style.outline = "none";
      currentlySelected.classList.remove("selected-ticket");
    }
    const clickedElement = event.currentTarget;
    clickedElement.classList.add("selected-ticket");
    clickedElement.style.setProperty("outline", "5px solid red", "!important");
  }

  tbodyElements.forEach((tbody) => {
    if (tbody.classList.contains("zero-progress-ticket")) {
      tbody.addEventListener("click", handleTbodyClick);
    }
  });
}

function processThemes(themes) {
  const storedTheme = localStorage.getItem('theme');
  const tbodyElements = document.querySelectorAll("#mainTableRow tbody.zero-progress-ticket");

  themes.forEach((tema) => {
    const temaNaziv = tema.theme;
    const boje = JSON.parse(tema.colors);
    sveBoje.push({ tema: temaNaziv, boje: boje });
  });

  setInitialTheme(tbodyElements, storedTheme);
}

function setInitialTheme(tbodyElements, storedTheme) {
  let themeIndex = sveBoje.findIndex(item => item.tema.toLowerCase() === storedTheme.toLowerCase());

  if (storedTheme && themeIndex !== -1) {
    theme = storedTheme;
    boje = sveBoje[themeIndex].boje;
  } else {
    if (sveBoje.length > 0) {
      theme = sveBoje[0].tema;
      boje = sveBoje[0].boje;
      localStorage.setItem('theme', theme);
    }
  }

  changeColor(tbodyElements);
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.themes) {
    processThemes(message.themes);
  }

  if (message.odabranaTema) {
    theme = message.odabranaTema;
    const selectedTheme = sveBoje.find(item => item.tema.toLowerCase() === theme.toLowerCase());
    if (selectedTheme) {
      boje = selectedTheme.boje;
      localStorage.setItem('theme', message.odabranaTema);
      Object.keys(orderIdColorMap).forEach(key => delete orderIdColorMap[key]);
      changeColor(document.querySelectorAll("#mainTableRow tbody.zero-progress-ticket"));
    } else {
      console.log("Odabrana tema nije pronađena.");
    }
  }
});

window.addEventListener("load", () => {
  const storedItems = localStorage.getItem('sortedItems');
  const storedTheme = localStorage.getItem('theme');
  const tbodyElements = document.querySelectorAll("#mainTableRow tbody.zero-progress-ticket");

  if (storedTheme) {
    theme = storedTheme;
    boje = theme === "neon" ? theme.neon : theme.pastele;
  }

  if (storedItems) {
    const sortedItems = JSON.parse(storedItems);
    sortedItems.forEach(item => {
      allTicketItems[item.itemId] = item;
    });
  } else {
    console.log('Podaci nisu pronađeni u lokalnoj pohrani.');
  }

  tbodyElements.forEach((tbody) => {
    editGlovoTicket(tbody);
    processTicket(tbody);
  });

  const tabContent = document.querySelector(".tab-content");
  const mainTable = document.querySelector("#mainTable");

  if (tabContent) tabContent.style.setProperty("height", "80vh");
  if (mainTable) mainTable.style.setProperty("height", "100%");

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (
          node.nodeType === 1 &&
          node.tagName.toLowerCase() === "tbody" &&
          node.classList.contains("zero-progress-ticket")
        ) {
          if (mainTable) mainTable.style.setProperty("height", "100%");
          tabContent.style.setProperty("height", "90vh");
          const ticketId = node.getAttribute("ticketid");
          let color;
          if (orderIdColorMap[ticketId]) {
            color = orderIdColorMap[ticketId];
          } else {
            color = chooseNextColor();
            orderIdColorMap[ticketId] = color;
          }
          const innerDiv = node.querySelector(".ticket_first_half_completed");
          if (innerDiv) {
            innerDiv.style.backgroundColor = color;
          }
          applyStylingToNewElement(node, color);
          processTicket(node);

          node.addEventListener("click", () => {
            const tbodyElements = document.querySelectorAll("#mainTableRow tbody");
            tbodyElements.forEach((tbody) => {
              if (tbody.classList.contains("selected-ticket")) selectedId = tbody.getAttribute("ticket_id");
              if (!tbody.classList.contains("selected-ticket") && tbody.getAttribute("ticket_id") === selectedId) {
                currentlySelected.style.outline = "5px solid red";
              }
              if (!tbody.classList.contains("selected-ticket")) {
                tbody.style.outline = "none";
              } else tbody.style.outline = "5px solid red";
            });
          });
        }
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class"],
  });
});

function applyStylingToNewElement(newElement, selectedColor) {
  const headerRow = newElement.querySelector(
    ".zero-progress-ticket.bg-blue-grey.white-text.text-center.ticket-row-header"
  );
  const lightColor = hexToRgba(selectedColor);
  newElement.style.backgroundColor = lightColor;
  newElement.style.outline = "none";
  newElement.style.borderRadius = "0 0 1rem 1rem";
  newElement.style.borderColor = selectedColor;
  newElement.style.color = "Black";
  newElement.style.boxShadow = `0px 0px 10px ${selectedColor}`;
  if (headerRow) {
    newElement.style.borderRadius = "1rem";
    headerRow.style.setProperty("background-color", selectedColor, "important");
    headerRow.style.setProperty("color", "white", "important");
    const naslov = headerRow.querySelector("span.ticket-title");
    naslov.style.setProperty("padding", "0");
    naslov.style.setProperty("text-shadow", "none");
    const h4 = naslov.parentElement;
    h4.style.setProperty("background", "black");
    h4.style.setProperty("text-align", "center");
    h4.style.borderRadius = "0.75rem 0.75rem 0 0";
    const headerCells = headerRow.querySelectorAll("td");
    headerCells.forEach((cell) => {
      cell.style.setProperty("font-weight", "600", "important");
    });
  }
}
