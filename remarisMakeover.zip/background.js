const supabaseUrl = 'https://xxqeupvmmmxltbtxcgvp.supabase.co/rest/v1';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh4cWV1cHZtbW14bHRidHhjZ3ZwIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njk1Nzk3MDYsImV4cCI6MTk4NTE1NTcwNn0.Pump9exBhsc1TbUGqegEsqIXnmsmlUZMVlo2gSHoYDo';



async function fetchTheme(url, key) {
    const response = await fetch(`${url}/remarisMakeoverThemes`, {
        method: 'GET',
        headers: {
            'apikey': key,
            'Authorization': `Bearer ${key}`,
        },
    });
    if (!response.ok) {
        throw new Error('Unable to fetch locations from Supabase');
    }
    return await response.json();
}
fetchTheme(supabaseUrl, supabaseKey)
    .then(themes => {
        console.log("Poslao theme");

        chrome.storage.local.set({ themes: themes })
    })
    .catch(error => {
        console.error('Greška pri dohvaćanju podataka o temama:', error);
    });

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete') {
        // Provjerite je li tab u kojem je stranica učitana aktivan
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            if (tabs.length > 0 && tabs[0].id === tabId) {
                // Ako je tab aktivan, pošaljite poruku u content skript
                fetchTheme(supabaseUrl, supabaseKey)
                    .then(data => {
                        console.log(data);
                        chrome.tabs.sendMessage(tabId, { themes: data });
                    })
                    .catch(error => {
                        console.error('Greška pri dohvaćanju podataka o temama:', error);
                    });
            }
        });
    }
});
